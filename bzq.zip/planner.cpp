/*=================================================================
 *
 * planner.c
 *
 *=================================================================*/
#include <math.h>
#include "mex.h"
#include <utility>
#include <queue>
#include <algorithm>
#include <chrono>

/* Input Arguments */
#define	MAP_IN      prhs[0]
#define	ROBOT_IN	prhs[1]
#define	GOAL_IN     prhs[2]


/* Output Arguments */
#define	ACTION_OUT	plhs[0]

//access to the map is shifted to account for 0-based indexing in the map, whereas
//1-based indexing in matlab (so, robotpose and goalpose are 1-indexed)
#define GETMAPINDEX(X, Y, XSIZE, YSIZE) ((Y-1)*XSIZE + (X-1))

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define NUMOFDIRS 8

const double INF = 2000000000;

int temp = 0;
double epsilon = 4.0;

int ABS(int x)
{
	return (x<0) ? -x : x;
}

typedef struct node
{
	int g;
	double prior;
	bool closed;
	int x;
	int y;
	int parent_x;
	int parent_y;
} node_t;

node_t* nodes[5002][5002];

int halfeuclidH (int x1, int x2, int y1, int y2)
{
	return 0.5*sqrt((x1-x2)*(x1-x2)*1.0 + (y1-y2)*(y1-y2)*1.0);
}

void compPrior(node_t* n, int goalX, int goalY)
{
	n->prior = n->g + epsilon * halfeuclidH(n->x, goalX, n->y, goalY);
}

node_t* nodePair(std::pair<int,int> p)
{
	return nodes[p.first][p.second];
}

void initNode(std::pair<int,int> coords)
{
	int i = coords.first;
	int j = coords.second;
	nodes[i][j] = new node_t();
 	nodes[i][j]->g = INF;
 	nodes[i][j]->prior = INF;
	nodes[i][j]->closed = false;
	nodes[i][j]->x = i;
	nodes[i][j]->y = j;
	nodes[i][j]->parent_x = -1;
	nodes[i][j]->parent_y = -1;
}
void deleteNodes(std::queue< std::pair<int,int> > *toDelete)
{
	while(!((*toDelete).empty()))
	{
		std::pair<int,int> coord = (*toDelete).front();
		delete nodes[coord.first][coord.second];
		(*toDelete).pop();
	}
}
struct CustomCompare {
public:
	bool operator() (const std::pair<int,int>& n1, const std::pair<int,int>& n2)
	{
		return nodePair(n1)->prior > nodePair(n2)->prior;
	}
};

std::pair<int,int> bestAction(int rX, int rY, int gX, int gY)
{
	if(nodes[gX][gY] == NULL) return std::make_pair(-2,-2);
	else if (nodes[gX][gY]->parent_x == rX && nodes[gX][gY]->parent_y == rY)
	{
		return std::make_pair(gX-rX,gY-rY);
	}else{
		return bestAction(rX,rY,nodes[gX][gY]->parent_x,nodes[gX][gY]->parent_y);
	}
}

static void planner(
		   double* map,
		   int x_size,
 		   int y_size,
           int robotposeX,
            int robotposeY,
            int goalposeX,
            int goalposeY,
            char *p_actionX,
            char *p_actionY
		   )
{
    //8-connected grid
    int dX[NUMOFDIRS] = {1, -1, 0,  0, 1,  1, -1, -1};
    int dY[NUMOFDIRS] = {0,  0, 1, -1, 1, -1,  1, -1};

		std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
		for(int i = 0; i < 5002; i++)
			for(int j = 0; j < 5002; j++)
				nodes[i][j] = NULL;
		std::chrono::steady_clock::time_point mid = std::chrono::steady_clock::now();
		int resetTime = std::chrono::duration_cast<std::chrono::milliseconds>(mid - begin).count();
    printf("call=%d\n", temp);
		printf("robot position: (%d,%d)\n",robotposeX,robotposeY);
		printf("goal position: (%d,%d)\n",goalposeX,goalposeY);
    temp = temp+1;

		std::priority_queue< std::pair<int,int>, std::vector< std::pair<int,int> >, CustomCompare> OPEN;
		std::priority_queue< std::pair<int,int>, std::vector< std::pair<int,int> >, CustomCompare> INCONS;
		std::queue< std::pair<int,int> > initializedNodes;

		OPEN.push(std::make_pair(robotposeX, robotposeY));
		initNode(std::make_pair(robotposeX, robotposeY));
		initializedNodes.push(std::make_pair(robotposeX, robotposeY));
		nodes[robotposeX][robotposeY]->g = 0;
		compPrior(nodes[robotposeX][robotposeY],goalposeX,goalposeY);
		const double decreasingEpsilons[] = {4.0, 3.0, 2.5, 2.0, 1.5, 1.0};
		int currentIter = 0;
		int timeDifference = 0;
		while(currentIter <= 5 && timeDifference <= 150){
			epsilon = decreasingEpsilons[currentIter];
			while(!INCONS.empty())
			{
				OPEN.push(INCONS.top());
				INCONS.pop();
			}
			double threshold = INF;
			while(!OPEN.empty() && threshold > nodePair(OPEN.top())->prior)
			{
				std::pair<int,int> curS = OPEN.top();
				OPEN.pop();
				nodePair(curS)->closed = true;
				int current_g = nodePair(curS)->g;
				for(int i = 0; i < NUMOFDIRS; i++)
				{
					int newX = curS.first + dX[i];
					int newY = curS.second + dY[i];
					if(newX >= 1 && newX <= x_size && newY >= 1 && newY <= y_size && (int)map[GETMAPINDEX(newX,newY,x_size,y_size)] == 0){
						if(nodes[newX][newY] == NULL){
							initNode(std::make_pair(newX,newY));
							initializedNodes.push(std::make_pair(newX,newY));
						}
						node_t* nextNode = nodes[newX][newY];
						if(nextNode->g > 1 + current_g)
						{
							nextNode->g = 1 + current_g;
							nextNode->parent_x = curS.first;
							nextNode->parent_y = curS.second;
							compPrior(nextNode,goalposeX,goalposeY);
							if (!(nextNode->closed)){
								OPEN.push(std::make_pair(newX, newY));
							}else{
								INCONS.push(std::make_pair(newX, newY));
							}
						}
					}
				}
				if(nodes[goalposeX][goalposeY] != NULL){
					 threshold = nodes[goalposeX][goalposeY]->prior;
				}
			}
			currentIter++;
			std::chrono::steady_clock::time_point checkpoint = std::chrono::steady_clock::now();
			timeDifference = std::chrono::duration_cast<std::chrono::milliseconds>(checkpoint - begin).count();
		}
		std::pair<int,int> bA = bestAction(robotposeX,robotposeY,goalposeX,goalposeY);
		if(bA.first == -2)
		{
			deleteNodes(&initializedNodes);
			printf("The robot is scared stiff!\n");
			return;
		}
		deleteNodes(&initializedNodes);
		*p_actionX = bA.first;
		*p_actionY = bA.second;
    return;
}

//prhs contains input parameters (3):
//1st is matrix with all the obstacles
//2nd is a row vector <x,y> for the robot pose
//3rd is a row vector <x,y> for the target pose
//plhs should contain output parameters (1):
//1st is a row vector <dx,dy> which corresponds to the action that the robot should make
void mexFunction( int nlhs, mxArray *plhs[],
		  int nrhs, const mxArray*prhs[] )

{

    /* Check for proper number of arguments */
    if (nrhs != 3) {
	    mexErrMsgIdAndTxt( "MATLAB:planner:invalidNumInputs",
                "Three input arguments required.");
    } else if (nlhs != 1) {
	    mexErrMsgIdAndTxt( "MATLAB:planner:maxlhs",
                "One output argument required.");
    }

    /* get the dimensions of the map and the map matrix itself*/
    int x_size = mxGetM(MAP_IN);
    int y_size = mxGetN(MAP_IN);
    double* map = mxGetPr(MAP_IN);

    /* get the dimensions of the robotpose and the robotpose itself*/
    int robotpose_M = mxGetM(ROBOT_IN);
    int robotpose_N = mxGetN(ROBOT_IN);
    if(robotpose_M != 1 || robotpose_N != 2){
	    mexErrMsgIdAndTxt( "MATLAB:planner:invalidrobotpose",
                "robotpose vector should be 1 by 2.");
    }
    double* robotposeV = mxGetPr(ROBOT_IN);
    int robotposeX = (int)robotposeV[0];
    int robotposeY = (int)robotposeV[1];

    /* get the dimensions of the goalpose and the goalpose itself*/
    int goalpose_M = mxGetM(GOAL_IN);
    int goalpose_N = mxGetN(GOAL_IN);
    if(goalpose_M != 1 || goalpose_N != 2){
	    mexErrMsgIdAndTxt( "MATLAB:planner:invalidgoalpose",
                "goalpose vector should be 1 by 2.");
    }
    double* goalposeV = mxGetPr(GOAL_IN);
    int goalposeX = (int)goalposeV[0];
    int goalposeY = (int)goalposeV[1];

    /* Create a matrix for the return action */
    ACTION_OUT = mxCreateNumericMatrix( (mwSize)1, (mwSize)2, mxINT8_CLASS, mxREAL);
    char* action_ptr = (char*)  mxGetPr(ACTION_OUT);

    /* Do the actual planning in a subroutine */
    planner(map, x_size, y_size, robotposeX, robotposeY, goalposeX, goalposeY, &action_ptr[0], &action_ptr[1]);
    return;

}
